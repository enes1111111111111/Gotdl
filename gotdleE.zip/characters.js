const characters = [
  {
    name: "Tyrion Lannister",
    house: "Lannister",
    gender: "Male",
    age: 32,
    origin: "Casterly Rock",
    image: "https://raw.githubusercontent.com/enes1111111111111/Gotdl-images/main/tyrion.jpg"
  },
  {
    name: "Jon Snow",
    house: "Stark",
    gender: "Male",
    age: 25,
    origin: "Winterfell",
    image: "https://raw.githubusercontent.com/enes1111111111111/Gotdl-images/main/images%20(3).jpeg"
  },
  {
    name: "Daenerys Targaryen",
    house: "Targaryen",
    gender: "Female",
    age: 24,
    origin: "Dragonstone",
    image: "https://raw.githubusercontent.com/enes1111111111111/Gotdl-images/main/images%20(5).jpeg"
  }
];